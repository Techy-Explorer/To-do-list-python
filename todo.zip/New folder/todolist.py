def main():
    task_list = []  
    
    while True:
        
        print(" My To-Do List")
        print("1. Add Task")
        print("2. Show Tasks") 
        print("3. Mark Task as Done")
        print("4. Exit")
        print("=" * 20)
        
        user_choice = input("What would you like to do? Enter your choice: ")
        
        if user_choice == '1':
            
            how_many = int(input("How many tasks do you want to add: "))
            for task_num in range(how_many):
                print(f"Task #{task_num + 1}:")
                new_task = input("Enter the task: ")
                
                
                while True:
                    try:
                        task_priority = int(input("Enter priority (1 = High, 2 = Medium, 3 = Low): "))
                        if task_priority in [1, 2, 3]:
                            break
                        else:
                            print("Please enter 1, 2, or 3 only!")
                    except ValueError:
                        print("Please enter a valid number!")
                
                
                task_dict = {
                    "task": new_task, 
                    "done": False, 
                    "priority": task_priority
                }
                task_list.append(task_dict)
                print(" Task added successfully!")
        
        elif user_choice == '2':
            
            if not task_list:  
                print("No tasks found! Add some tasks first.")
            else:
                print(" Your Tasks (sorted by priority) ")
                sorted_tasks = sorted(task_list, key=lambda x: x["priority"])
                
                for idx, current_task in enumerate(sorted_tasks):
                    task_status = " Done" if current_task["done"] else "○ Not Done"
                    priority_text = ""
                    if current_task["priority"] == 1:
                        priority_text = "HIGH"
                    elif current_task["priority"] == 2:
                        priority_text = "MEDIUM"  
                    else:
                        priority_text = "LOW"
                    
                    print(f"{idx + 1}. {current_task['task']} - {task_status} - Priority: {priority_text}")
        
        elif user_choice == '3':
            
            if not task_list:
                print("No tasks available to mark as done!")
            else:
                
                print("\nCurrent tasks:")
                sorted_for_display = sorted(task_list, key=lambda x: x["priority"])
                for i, t in enumerate(sorted_for_display):
                    status = "done" if t["done"] else "failed"
                    print(f"{i + 1}. {t['task']} [{status}]")
                
                try:
                    task_to_complete = int(input("\nEnter the task number to mark as done: ")) - 1
                    if 0 <= task_to_complete < len(task_list):
                    
                        
                        sorted_list = sorted(task_list, key=lambda x: x["priority"])
                        selected_task = sorted_list[task_to_complete]
                        selected_task["done"] = True
                        print(f" Task '{selected_task['task']}' marked as done!")
                    else:
                        print("Oops! Invalid task number. Please try again.")
                except ValueError:
                    print("Please enter a valid number!")
        
        elif user_choice == '4':
            print("Thanks for using the To-Do List! Goodbye!")
            break
        
        else:
            print("Hmm, that's not a valid choice. Please pick 1, 2, 3, or 4.")

if __name__ == "__main__":
    main()