from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load model
model = pickle.load(open("model.pkl", "rb"))

# Load encoders
encoders = pickle.load(open("encoders.pkl", "rb"))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    Date = request.form["Date"]
    Mode = request.form["Mode"]
    Category = request.form["Category"]
    Subcategory = request.form["Subcategory"]
    Note = request.form["Note"]
    Amount = float(request.form["Amount"])
    Currency = request.form["Currency"]

    # Convert to dataframe
    input_df = pd.DataFrame([[Date, Mode, Category, Subcategory, Note, Amount, Currency]],
                            columns=["Date", "Mode", "Category", "Subcategory", "Note", "Amount", "Currency"])

    # Encode text columns
    for col in input_df.columns:
        if col in encoders:
            input_df[col] = encoders[col].transform(input_df[col].astype(str))

    # Predict
    prediction = model.predict(input_df)[0]

    result = "Income" if prediction == 1 else "Expense"

    return render_template("index.html", prediction=result)

if __name__ == "__main__":
    app.run(debug=True)
